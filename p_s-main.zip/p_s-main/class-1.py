# print("Hello World")
# print("22222")

# print(10 + 15)
# print(4 ** 2)
# print(25 // 2)

# print("Hello" + "World")

# a = "1"
# b = "5"
# c = 3
# d = a + b
# print(int(d) + c)

# c = 3.14568
# print(round(c, 2))

# Home Work progressia
# item_1 = input("Please enter first digit: ")
# item_2 = input("Please enter second digit: ")
# item_N = input("Please enter N code: ")
#
# d_tarber = int(item_2) - int(item_1)
# ancver = int(item_1) + d_tarber * (int(item_N) - 1)
# print(ancver)

# Home Work DAR
# year = int(input("Please enter the year: "))
# dar = (year - 1) // 100
# print(dar + 1)

